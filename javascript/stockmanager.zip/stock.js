class Stock {
    constructor(stno, stname, stamt, stindate, strgdate, shno) {
        this.stno = stno;
        this.stname = stname;
        this.stamt = stamt;
        this.stindate = stindate;
        this.strgdate = strgdate;
        this.shno = shno;
    }
}







