class Shop {
    constructor(shno, shname, shtotst){
        this.shno = shno;
        this.shname = shname;
        this.shtotst = shtotst;        
    }
}

